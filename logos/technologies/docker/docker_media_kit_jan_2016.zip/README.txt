Docker, Inc is the exclusive owner of the trademarks DOCKER and the Docker Whale Design. To protect its trademark rights, Docker, Inc is required to control the use of its marks by others and the quality of the services with which they are used by permission. 

Please refer to our online brand guidelines at https://www.docker.com/brand-guidelines for directions on how to use the Docker logo.